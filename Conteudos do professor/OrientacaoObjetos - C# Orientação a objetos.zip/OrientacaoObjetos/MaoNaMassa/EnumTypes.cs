﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrientacaoObjetos.MaoNaMassa
{
    public enum TipoPessoa
    {
        Fisica,
        Juridica,
    }

    public enum TipoCredito
    {
        Pessoal,
        Imobiliaria,
        Automotivo,
    }
}